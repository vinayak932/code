import { NextResponse } from "next/server"

const INDIAN_STOCKS = [
  { symbol: "RELIANCE.NS", name: "Reliance Industries Ltd" },
  { symbol: "TCS.NS", name: "Tata Consultancy Services" },
  { symbol: "HDFCBANK.NS", name: "HDFC Bank Ltd" },
  { symbol: "INFY.NS", name: "Infosys Ltd" },
  { symbol: "ICICIBANK.NS", name: "ICICI Bank Ltd" },
  { symbol: "HINDUNILVR.NS", name: "Hindustan Unilever Ltd" },
  { symbol: "ITC.NS", name: "ITC Ltd" },
  { symbol: "SBIN.NS", name: "State Bank of India" },
]

async function fetchYahooFinanceData(symbol: string) {
  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

    const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${symbol}`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()

    if (!data.chart || !data.chart.result || !data.chart.result[0]) {
      throw new Error("Invalid response structure")
    }

    const result = data.chart.result[0]
    const meta = result.meta

    if (!meta) {
      throw new Error("No meta data available")
    }

    const currentPrice = meta.regularMarketPrice || meta.previousClose || 0
    const previousClose = meta.previousClose || currentPrice
    const change = currentPrice - previousClose
    const changePercent = previousClose !== 0 ? (change / previousClose) * 100 : 0

    return {
      symbol: symbol.replace(".NS", ""),
      fullSymbol: symbol,
      price: currentPrice,
      change: change,
      changePercent: changePercent,
      volume: meta.regularMarketVolume || 0,
      marketCap: meta.marketCap || 0,
      high: meta.regularMarketDayHigh || currentPrice,
      low: meta.regularMarketDayLow || currentPrice,
    }
  } catch (error) {
    console.error(`Error fetching data for ${symbol}:`, error.message)
    return null
  }
}

// Fallback stock data
function getFallbackStockData() {
  return [
    {
      symbol: "RELIANCE",
      name: "Reliance Industries Ltd",
      price: 2456.75,
      change: 23.45,
      changePercent: 0.96,
      volume: 1000000,
      marketCap: 1500000000000,
      high: 2480,
      low: 2430,
      fallback: true,
    },
    {
      symbol: "TCS",
      name: "Tata Consultancy Services",
      price: 3789.2,
      change: -45.3,
      changePercent: -1.18,
      volume: 800000,
      marketCap: 1400000000000,
      high: 3820,
      low: 3760,
      fallback: true,
    },
    {
      symbol: "HDFCBANK",
      name: "HDFC Bank Ltd",
      price: 1678.9,
      change: 12.85,
      changePercent: 0.77,
      volume: 1200000,
      marketCap: 900000000000,
      high: 1690,
      low: 1665,
      fallback: true,
    },
    {
      symbol: "INFY",
      name: "Infosys Ltd",
      price: 1534.6,
      change: 28.7,
      changePercent: 1.91,
      volume: 900000,
      marketCap: 650000000000,
      high: 1545,
      low: 1520,
      fallback: true,
    },
    {
      symbol: "ICICIBANK",
      name: "ICICI Bank Ltd",
      price: 1089.45,
      change: -8.25,
      changePercent: -0.75,
      volume: 1100000,
      marketCap: 750000000000,
      high: 1095,
      low: 1080,
      fallback: true,
    },
    {
      symbol: "HINDUNILVR",
      name: "Hindustan Unilever Ltd",
      price: 2234.8,
      change: 15.6,
      changePercent: 0.7,
      volume: 600000,
      marketCap: 520000000000,
      high: 2245,
      low: 2220,
      fallback: true,
    },
    {
      symbol: "ITC",
      name: "ITC Ltd",
      price: 456.3,
      change: 3.45,
      changePercent: 0.76,
      volume: 2000000,
      marketCap: 570000000000,
      high: 460,
      low: 452,
      fallback: true,
    },
    {
      symbol: "SBIN",
      name: "State Bank of India",
      price: 623.75,
      change: -12.4,
      changePercent: -1.95,
      volume: 1500000,
      marketCap: 550000000000,
      high: 635,
      low: 620,
      fallback: true,
    },
  ]
}

export async function GET() {
  try {
    const stockPromises = INDIAN_STOCKS.map(async (stock) => {
      const data = await fetchYahooFinanceData(stock.symbol)
      if (data) {
        return {
          ...data,
          name: stock.name,
          fallback: false,
        }
      }
      return null
    })

    const results = await Promise.all(stockPromises)
    const validStocks = results.filter((stock) => stock !== null)

    // If we got at least half the stocks, return what we have
    if (validStocks.length >= INDIAN_STOCKS.length / 2) {
      return NextResponse.json(validStocks)
    }

    // If most APIs failed, return fallback data
    console.log("Most stock APIs failed, using fallback data")
    return NextResponse.json(getFallbackStockData())
  } catch (error) {
    console.error("Error in stocks API:", error)
    return NextResponse.json(getFallbackStockData())
  }
}
