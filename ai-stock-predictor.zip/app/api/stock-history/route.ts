import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const symbol = searchParams.get("symbol")
  const period = searchParams.get("period") || "1mo"

  if (!symbol) {
    return NextResponse.json({ error: "Symbol is required" }, { status: 400 })
  }

  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 15000) // 15 second timeout

    const response = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}.NS?period1=0&period2=9999999999&interval=1d&range=${period}`,
      {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
        signal: controller.signal,
      },
    )

    clearTimeout(timeoutId)

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()

    if (!data.chart || !data.chart.result || !data.chart.result[0]) {
      throw new Error("No chart data available")
    }

    const result = data.chart.result[0]

    if (!result.timestamp || !result.indicators || !result.indicators.quote || !result.indicators.quote[0]) {
      throw new Error("Invalid data structure")
    }

    const timestamps = result.timestamp
    const prices = result.indicators.quote[0]

    const historicalData = timestamps
      .map((timestamp: number, index: number) => ({
        date: new Date(timestamp * 1000).toISOString().split("T")[0],
        open: prices.open[index] || 0,
        high: prices.high[index] || 0,
        low: prices.low[index] || 0,
        close: prices.close[index] || 0,
        volume: prices.volume[index] || 0,
      }))
      .filter((item: any) => item.close !== null && item.close > 0)

    if (historicalData.length === 0) {
      throw new Error("No valid historical data found")
    }

    return NextResponse.json(historicalData)
  } catch (error) {
    console.error("Error fetching historical data:", error)

    // Return fallback historical data
    const fallbackData = generateFallbackHistoricalData(symbol, period)
    return NextResponse.json(fallbackData)
  }
}

function generateFallbackHistoricalData(symbol: string, period: string) {
  const days = period === "1mo" ? 30 : period === "3mo" ? 90 : 30
  const basePrice = 1000 + Math.random() * 2000 // Random base price
  const data = []

  for (let i = days; i >= 0; i--) {
    const date = new Date()
    date.setDate(date.getDate() - i)

    const price = basePrice + (Math.random() - 0.5) * 200
    data.push({
      date: date.toISOString().split("T")[0],
      open: price,
      high: price * (1 + Math.random() * 0.05),
      low: price * (1 - Math.random() * 0.05),
      close: price,
      volume: Math.floor(Math.random() * 1000000),
    })
  }

  return data
}
