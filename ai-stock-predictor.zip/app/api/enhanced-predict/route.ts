import { streamText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(req: Request) {
  const { messages, stockData, technicalAnalysis, newsSentiment } = await req.json()

  const enhancedContext = `
COMPREHENSIVE STOCK ANALYSIS CONTEXT:

CURRENT STOCK DATA:
${stockData ? JSON.stringify(stockData, null, 2) : "No stock data"}

TECHNICAL ANALYSIS:
${technicalAnalysis ? JSON.stringify(technicalAnalysis, null, 2) : "No technical analysis"}

NEWS SENTIMENT:
${newsSentiment ? JSON.stringify(newsSentiment, null, 2) : "No sentiment data"}

ANALYSIS FRAMEWORK:
1. Technical Indicators Weight: 40%
   - RSI: ${technicalAnalysis?.signals?.rsi?.signal || "N/A"} (${technicalAnalysis?.signals?.rsi?.value?.toFixed(2) || "N/A"})
   - MACD: ${technicalAnalysis?.signals?.macd?.signal || "N/A"}
   - Bollinger Bands: ${technicalAnalysis?.signals?.bollinger?.signal || "N/A"}
   - Trend: ${technicalAnalysis?.signals?.trend?.signal || "N/A"}

2. Sentiment Analysis Weight: 30%
   - Overall Sentiment: ${newsSentiment?.sentiment?.sentimentLabel || "N/A"}
   - Confidence: ${newsSentiment?.sentiment?.confidence?.toFixed(2) || "N/A"}

3. Price Action Weight: 20%
   - Current Trend: ${stockData?.changePercent > 0 ? "BULLISH" : "BEARISH"}
   - Momentum: ${Math.abs(stockData?.changePercent || 0) > 2 ? "STRONG" : "WEAK"}

4. Market Context Weight: 10%
   - Market Hours: ${new Date().getHours() >= 9 && new Date().getHours() < 16 ? "OPEN" : "CLOSED"}
   - Day of Week: ${new Date().toLocaleDateString("en-US", { weekday: "long" })}
`

  const result = await streamText({
    model: openai("gpt-4o"),
    messages,
    system: `You are an advanced AI stock analyst with access to comprehensive market data including technical indicators, sentiment analysis, and real-time price movements.

${enhancedContext}

PREDICTION METHODOLOGY:
1. Analyze all technical indicators with their respective weights
2. Factor in news sentiment and market psychology
3. Consider current price action and momentum
4. Account for market timing and conditions
5. Provide confidence levels based on signal alignment

OUTPUT REQUIREMENTS:
- Direction: BUY/SELL/HOLD with clear reasoning
- Confidence Level: 60-95% based on signal convergence
- Target Price: Specific price with timeframe
- Stop Loss: Risk management level
- Key Factors: Top 3 factors influencing the prediction
- Risk Assessment: High/Medium/Low with explanation

ACCURACY FACTORS:
- Signal Convergence: Higher accuracy when multiple indicators align
- Sentiment Alignment: Technical + Fundamental + Sentiment agreement
- Market Conditions: Consider volatility and market phase
- Time Horizon: Specify short-term (1-3 days) vs medium-term (1-2 weeks)

Focus on actionable insights with clear risk-reward ratios for Indian market context.`,
  })

  return result.toDataStreamResponse()
}
