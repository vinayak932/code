import { NextResponse } from "next/server"

const INDICES = [
  { symbol: "^NSEI", name: "NIFTY 50", fallback: "NIFTY_50.NS" },
  { symbol: "^BSESN", name: "SENSEX", fallback: "BSE.BO" },
  { symbol: "^NSEBANK", name: "BANK NIFTY", fallback: "BANKNIFTY.NS" },
]

async function fetchIndexData(symbol: string, fallback?: string) {
  const symbols = [symbol, fallback].filter(Boolean)

  for (const sym of symbols) {
    try {
      const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${sym}`, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
        timeout: 10000, // 10 second timeout
      })

      if (!response.ok) {
        console.log(`Failed to fetch ${sym}: ${response.status}`)
        continue
      }

      const data = await response.json()

      if (!data.chart || !data.chart.result || !data.chart.result[0]) {
        console.log(`No data in response for ${sym}`)
        continue
      }

      const result = data.chart.result[0]
      const meta = result.meta

      if (!meta) {
        console.log(`No meta data for ${sym}`)
        continue
      }

      const currentPrice = meta.regularMarketPrice || meta.previousClose || 0
      const previousClose = meta.previousClose || currentPrice
      const change = currentPrice - previousClose
      const changePercent = previousClose !== 0 ? (change / previousClose) * 100 : 0

      return {
        symbol: sym,
        price: currentPrice,
        change: change,
        changePercent: changePercent,
        volume: meta.regularMarketVolume || 0,
        success: true,
      }
    } catch (error) {
      console.error(`Error fetching data for ${sym}:`, error.message)
      continue
    }
  }

  return null
}

// Fallback data for when APIs fail
function getFallbackData() {
  return [
    {
      symbol: "^NSEI",
      name: "NIFTY 50",
      price: 21456.78,
      change: 145.32,
      changePercent: 0.68,
      volume: 0,
      fallback: true,
    },
    {
      symbol: "^BSESN",
      name: "SENSEX",
      price: 71234.56,
      change: -89.45,
      changePercent: -0.13,
      volume: 0,
      fallback: true,
    },
    {
      symbol: "^NSEBANK",
      name: "BANK NIFTY",
      price: 45678.9,
      change: 234.67,
      changePercent: 0.52,
      volume: 0,
      fallback: true,
    },
  ]
}

export async function GET() {
  try {
    const indexPromises = INDICES.map(async (index) => {
      const data = await fetchIndexData(index.symbol, index.fallback)
      if (data) {
        return {
          ...data,
          name: index.name,
          fallback: false,
        }
      }
      return null
    })

    const results = await Promise.all(indexPromises)
    const validIndices = results.filter((index) => index !== null)

    // If we got some data, return it
    if (validIndices.length > 0) {
      return NextResponse.json(validIndices)
    }

    // If all APIs failed, return fallback data
    console.log("All market index APIs failed, using fallback data")
    return NextResponse.json(getFallbackData())
  } catch (error) {
    console.error("Error in market indices API:", error)

    // Return fallback data on any error
    return NextResponse.json(getFallbackData())
  }
}
