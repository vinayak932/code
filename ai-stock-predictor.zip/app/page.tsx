"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, TrendingDown, Search, RefreshCw, Brain, IndianRupee } from "lucide-react"
import { StockChart } from "@/components/stock-chart"
import { PredictionCard } from "@/components/prediction-card"
import { StockCard } from "@/components/stock-card"
import { MarketOverview } from "@/components/market-overview"
import { SocialSentimentCard } from "@/components/social-sentiment-card"
import { VolumeAnalysisCard } from "@/components/volume-analysis-card"
import { MarketSentimentOverview } from "@/components/market-sentiment-overview"

// Simulated Indian stock data
const INDIAN_STOCK_SYMBOLS = [
  "RELIANCE.NS",
  "TCS.NS",
  "HDFCBANK.NS",
  "INFY.NS",
  "ICICIBANK.NS",
  "HINDUNILVR.NS",
  "ITC.NS",
  "SBIN.NS",
]

export default function StockPredictor() {
  const [stocks, setStocks] = useState<any[]>([])
  const [selectedStock, setSelectedStock] = useState<any>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [lastUpdated, setLastUpdated] = useState(new Date())
  const [loading, setLoading] = useState(true)

  // Simulate real-time price updates
  useEffect(() => {
    const fetchStockData = async () => {
      try {
        setLoading(true)
        const response = await fetch("/api/stocks")
        const data = await response.json()
        setStocks(data)
        if (data.length > 0) {
          setSelectedStock(data[0])
        }
      } catch (error) {
        console.error("Error fetching stock data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchStockData()

    // Fetch data every 30 seconds
    const interval = setInterval(fetchStockData, 30000)
    return () => clearInterval(interval)
  }, [])

  const handleRefresh = async () => {
    setIsRefreshing(true)
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))
    // setStocks((prevStocks) =>
    //   prevStocks.map((stock) => ({
    //     ...stock,
    //     price: stock.price + (Math.random() - 0.5) * 15,
    //     change: (Math.random() - 0.5) * 25,
    //     changePercent: (Math.random() - 0.5) * 4,
    //   })),
    // )
    setLastUpdated(new Date())
    setIsRefreshing(false)
  }

  const filteredStocks = stocks.filter(
    (stock: any) =>
      stock?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      stock?.symbol?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="text-gray-600">Loading stock data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            AI Stock Predictor
          </h1>
          <p className="text-gray-600">Real-time Indian Stock Market Analysis & Predictions</p>
          <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
            <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
            <Button variant="ghost" size="sm" onClick={handleRefresh} disabled={isRefreshing} className="h-6 w-6 p-0">
              <RefreshCw className={`h-3 w-3 ${isRefreshing ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </div>

        {/* Market Overview */}
        <MarketOverview />

        {/* Search Bar */}
        <div className="flex gap-4 items-center">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search stocks..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Badge variant="secondary" className="flex items-center gap-1">
            <Brain className="h-3 w-3" />
            AI Powered
          </Badge>
        </div>

        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="predictions">AI Predictions</TabsTrigger>
            <TabsTrigger value="analysis">Technical Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            {/* Stock Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredStocks.slice(0, 8).map((stock: any) => (
                <StockCard
                  key={stock.symbol}
                  stock={stock}
                  isSelected={selectedStock?.symbol === stock.symbol}
                  onClick={() => setSelectedStock(stock)}
                />
              ))}
            </div>

            {/* Selected Stock Chart */}
            {selectedStock && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div>
                      <span>{selectedStock.name}</span>
                      <Badge variant="outline" className="ml-2">
                        {selectedStock.symbol}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <IndianRupee className="h-4 w-4" />
                      <span className="text-2xl font-bold">{selectedStock.price.toFixed(2)}</span>
                      <Badge variant={selectedStock.change >= 0 ? "default" : "destructive"}>
                        {selectedStock.change >= 0 ? "+" : ""}
                        {selectedStock.change.toFixed(2)}({selectedStock.changePercent.toFixed(2)}%)
                      </Badge>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <StockChart stock={selectedStock} />
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="predictions" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredStocks.slice(0, 6).map((stock: any) => (
                <PredictionCard key={stock.symbol} stock={stock} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analysis" className="space-y-6">
            {/* Market Sentiment Overview */}
            <MarketSentimentOverview />

            {/* Individual Stock Analysis */}
            {selectedStock && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <SocialSentimentCard symbol={selectedStock.symbol} />
                <VolumeAnalysisCard symbol={selectedStock.symbol} />
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Top Movers</CardTitle>
                  <CardDescription>Biggest gainers and losers</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {stocks
                      .sort((a: any, b: any) => Math.abs(b.changePercent) - Math.abs(a.changePercent))
                      .slice(0, 5)
                      .map((stock: any) => (
                        <div key={stock.symbol} className="flex justify-between items-center">
                          <div>
                            <span className="font-medium">{stock.symbol}</span>
                            <p className="text-sm text-gray-500">{stock.name}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            {stock.changePercent >= 0 ? (
                              <TrendingUp className="h-4 w-4 text-green-500" />
                            ) : (
                              <TrendingDown className="h-4 w-4 text-red-500" />
                            )}
                            <Badge variant={stock.changePercent >= 0 ? "default" : "destructive"}>
                              {stock.changePercent.toFixed(2)}%
                            </Badge>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Market Insights</CardTitle>
                  <CardDescription>Key market observations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Strong institutional buying in banking sector</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span>IT stocks showing resilience amid global concerns</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                      <span>Pharma sector experiencing rotation</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                      <span>FII activity remains cautiously optimistic</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
