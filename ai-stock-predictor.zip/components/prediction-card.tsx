"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Brain, TrendingUp, TrendingDown, Target, IndianRupee } from "lucide-react"
import { useChat } from "ai/react"

interface Stock {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
}

interface PredictionCardProps {
  stock: Stock
}

export function PredictionCard({ stock }: PredictionCardProps) {
  const [prediction, setPrediction] = useState<{
    direction: "up" | "down"
    confidence: number
    targetPrice: number
    timeframe: string
    reasoning: string
  } | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)

  const { messages, append, isLoading } = useChat({
    api: "/api/predict",
  })

  const generatePrediction = async () => {
    setIsGenerating(true)

    // Simulate AI prediction generation
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const direction = Math.random() > 0.5 ? "up" : "down"
    const confidence = Math.floor(Math.random() * 30) + 60 // 60-90%
    const targetPrice =
      direction === "up" ? stock.price * (1 + Math.random() * 0.15) : stock.price * (1 - Math.random() * 0.15)

    const reasons = [
      "Strong technical indicators suggest momentum continuation",
      "Positive earnings outlook and sector performance",
      "Market sentiment analysis shows bullish trends",
      "Volume analysis indicates institutional interest",
      "Support/resistance levels favor this direction",
      "Sector rotation patterns support this movement",
    ]

    setPrediction({
      direction,
      confidence,
      targetPrice,
      timeframe: "1-3 days",
      reasoning: reasons[Math.floor(Math.random() * reasons.length)],
    })

    setIsGenerating(false)
  }

  useEffect(() => {
    // Auto-generate prediction on mount
    generatePrediction()
  }, [stock.symbol])

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-blue-500/10 to-transparent rounded-bl-full" />

      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-lg">
          <div className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-blue-500" />
            <span>{stock.symbol}</span>
          </div>
          <Badge variant="outline" className="text-xs">
            AI Prediction
          </Badge>
        </CardTitle>
        <CardDescription className="text-sm">{stock.name}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Current Price</span>
          <div className="flex items-center gap-1">
            <IndianRupee className="h-3 w-3" />
            <span className="font-semibold">{stock.price.toFixed(2)}</span>
          </div>
        </div>

        {prediction && !isGenerating ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {prediction.direction === "up" ? (
                  <TrendingUp className="h-4 w-4 text-green-500" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-red-500" />
                )}
                <span className="font-medium capitalize">{prediction.direction}ward</span>
              </div>
              <Badge variant={prediction.direction === "up" ? "default" : "destructive"}>
                {prediction.confidence}% confidence
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-blue-500" />
                <span className="text-sm">Target Price</span>
              </div>
              <div className="flex items-center gap-1">
                <IndianRupee className="h-3 w-3" />
                <span className="font-semibold text-blue-600">{prediction.targetPrice.toFixed(2)}</span>
              </div>
            </div>

            <div className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
              <strong>Timeframe:</strong> {prediction.timeframe}
            </div>

            <div className="text-xs text-gray-600 bg-blue-50 p-2 rounded">
              <strong>AI Reasoning:</strong> {prediction.reasoning}
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          </div>
        )}

        <Button
          onClick={generatePrediction}
          disabled={isGenerating}
          variant="outline"
          size="sm"
          className="w-full bg-transparent"
        >
          {isGenerating ? "Analyzing..." : "Refresh Prediction"}
        </Button>
      </CardContent>
    </Card>
  )
}
